$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker was not found. Install and start Docker Desktop first."
}

docker compose ps

$rpcUrl = "http://127.0.0.1:8545"
$chainRequest = @{
    jsonrpc = "2.0"
    method  = "eth_chainId"
    params  = @()
    id      = 1
} | ConvertTo-Json -Compress
$blockRequest = @{
    jsonrpc = "2.0"
    method  = "eth_blockNumber"
    params  = @()
    id      = 2
} | ConvertTo-Json -Compress

try {
    $chainResponse = Invoke-RestMethod -Uri $rpcUrl -Method Post -ContentType "application/json" -Body $chainRequest -TimeoutSec 3
    $blockResponse = Invoke-RestMethod -Uri $rpcUrl -Method Post -ContentType "application/json" -Body $blockRequest -TimeoutSec 3
    $chainId = [Convert]::ToInt64($chainResponse.result.Substring(2), 16)
    $blockNumber = [Convert]::ToInt64($blockResponse.result.Substring(2), 16)

    Write-Host "RPC status: online" -ForegroundColor Green
    Write-Host ("Chain ID: {0}" -f $chainId)
    Write-Host ("Current block: {0}" -f $blockNumber)
}
catch {
    Write-Host "RPC status: unavailable" -ForegroundColor Red
    throw
}
