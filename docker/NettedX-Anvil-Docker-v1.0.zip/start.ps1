$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker was not found. Install and start Docker Desktop, then run this script again."
}

docker info | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "The Docker service is not running. Start Docker Desktop first."
}

Write-Host "Starting the NettedX Anvil private chain..." -ForegroundColor Cyan
docker compose up --detach --build
if ($LASTEXITCODE -ne 0) {
    throw "Container startup failed. Run: docker compose logs anvil"
}

Write-Host "Waiting for the health check..."
for ($attempt = 1; $attempt -le 30; $attempt++) {
    $status = docker inspect --format "{{.State.Health.Status}}" nettedx-anvil 2>$null
    if ($status -eq "healthy") {
        Write-Host "NettedX is ready at http://127.0.0.1:8545 (Chain ID 31337)." -ForegroundColor Green
        docker compose ps
        exit 0
    }

    if ($status -eq "unhealthy") {
        docker compose logs --tail 50 anvil
        throw "The Anvil health check failed."
    }

    Start-Sleep -Seconds 1
}

docker compose logs --tail 50 anvil
throw "Timed out while waiting for Anvil to start."
