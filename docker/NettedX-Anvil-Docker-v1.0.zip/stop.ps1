$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker was not found. Install Docker Desktop first."
}

docker compose down
if ($LASTEXITCODE -ne 0) {
    throw "Failed to stop the containers."
}

Write-Host "The NettedX container is stopped. Chain state remains in the nettedx-anvil-data volume." -ForegroundColor Green
