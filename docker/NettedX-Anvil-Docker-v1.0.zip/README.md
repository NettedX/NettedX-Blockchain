# NettedX Anvil Docker 私链

这是 NettedX 黑客松项目的本地开发私链包，基于 Foundry/Anvil v1.7.1，并通过同目录下的小写 `dockfile` 构建。

## 默认配置

- RPC：`http://127.0.0.1:8545`
- Chain ID：`31337`
- 测试账户：10 个
- 每个账户初始余额：10,000 ETH
- 出块方式：收到交易时自动出块
- 数据保存：Docker 数据卷 `nettedx-anvil-data`

## 第一次运行

1. 安装并启动 Docker Desktop。
2. 在本文件所在目录打开 PowerShell。
3. 运行：

   ```powershell
   .\start.ps1
   ```

第一次启动需要从 GitHub Container Registry 下载 Foundry 官方基础镜像并构建 `nettedx/anvil:v1.7.1`，因此需要联网。以后直接启动已有镜像即可。

## 常用操作

查看状态：

```powershell
.\status.ps1
```

查看实时日志：

```powershell
docker compose logs --follow anvil
```

停止私链但保留数据：

```powershell
.\stop.ps1
```

重新启动时，Anvil 会从数据卷中的 `state.json` 恢复区块、余额和已部署合约。

如果确实要清空整条测试链并重新从区块 0 开始，可运行 `docker compose down --volumes`。这会永久删除当前容器链数据。

## 前后端连接

在宿主机上运行的前端或后端使用：

```text
http://127.0.0.1:8545
```

如果后端也加入同一个 Compose 项目，应使用容器网络地址：

```text
http://anvil:8545
```

## 安全说明

`.env` 中是公开的 Anvil 测试助记词，只能用于本地开发和演示。不要向这些账户转入真实资产，不要把这套私钥用于任何公网或正式网络。

端口默认仅绑定 `127.0.0.1`。如需局域网联调，可把 `.env` 中的 `ANVIL_BIND_ADDRESS` 改成 `0.0.0.0`，但不要把 8545 端口直接暴露到互联网。
